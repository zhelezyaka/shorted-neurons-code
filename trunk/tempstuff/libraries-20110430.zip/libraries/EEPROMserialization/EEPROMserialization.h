#ifndef EEPROMserialization_h
#define EEPROMserialization_h

#include <EEPROM.h>
#include <WProgram.h>

/*
template <class T> int EEPROM_writeAnything(int ee, const T& value);
template <class T> int EEPROM_readAnything(int ee, T& value);
*/

/*
int EEPROM_writeAnything(int ee, const T& value);
int EEPROM_readAnything(int ee, T& value);
*/


#endif
